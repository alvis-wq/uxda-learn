# UXDA Learn — project instructions

Internal learning platform for UXDA. Team members sign in with Google (@theuxda.com only),
complete challenges (quizzes, screenshot/Figma submissions), get scored, and appear on a
leaderboard split into Strategists and Designers. Owner/admin: Alvis ("Vision").

## Stack (fixed — don't swap)
- Next.js (latest stable, App Router) + TypeScript (strict)
- Supabase: Postgres, Auth (Google), Storage. Client via `@supabase/ssr`
- Tailwind + shadcn/ui, lucide-react icons
- Zod for all schemas (content files, form input, eval results)
- Vitest (unit), Playwright (E2E)
- Supabase CLI for migrations and type generation
- Keep it host-portable: no Vercel-only features (Edge Config, KV, etc.)

## Architecture
- `/content` — source of truth for categories and challenges (YAML/Markdown). Synced to DB.
- Supabase — source of truth for users, submissions, evaluations, scores.
- `/scripts` — content validate/sync, eval pull/push, seed admins.
- `/.claude/commands` — `/new-challenge`, `/evaluate`.
- Full DB spec: `docs/schema.sql`. Content format: `docs/content-format.md`.

## Core rules
- **Security first.** RLS on every table. Answer keys and grader notes live in
  `challenge_keys` and must never reach the client. The service role key is server-only
  (never `NEXT_PUBLIC_`, never imported in client components).
- All submission writes go through server actions using the service role after verifying
  the session user. Users can never set their own scores or status.
- Users see categories with audience `all` plus their own track.
- Scoring: a challenge's `points` = sum of question points + rubric points. Best published
  attempt per challenge counts. Max 3 attempts.
- Quiz-only challenges (all questions auto-gradable) publish immediately on submit.
  Anything with screenshots, Figma, reflection or text questions goes:
  `submitted → ai_reviewed (via /evaluate) → published` (admin approves)
  or `→ needs_resubmission`.
- Never delete challenges that have submissions — archive them. Content changes bump `version`.
- Test login (email/password test users) only when `ENABLE_TEST_LOGIN=true` AND
  `NODE_ENV !== 'production'`. Guard it in code and test the guard.

## UI
Clean, calm, professional. Light and dark mode via shadcn. Accent colour `#B5A2FF`.
Mobile-friendly. Every list has an empty state; every async action has loading + error states.

## Working conventions
- Follow BUILD_PLAN.md. Log progress in `PROGRESS.md`, choices in `DECISIONS.md`
  (one line each: decision — reason).
- Run the checks before claiming anything works. Never skip, weaken or delete a test to
  make it pass. Never disable RLS to make something work.
- Commit after each completed phase: `phase N: <summary>`. Push only if `origin` exists.
- Prefer server components; client components only where interaction needs it.
- Regenerate DB types after every migration: `npm run db:types`.
